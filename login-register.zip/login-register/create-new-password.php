<?php
session_start();
if (isset($_SESSION["user"])) {
   header("Location: index.php");
}
?>
<!DOCTYPE html>
    <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title> Redefinir senha </title>
            <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
            <link rel="stylesheet" href="style.css">
        </head>
        <body>
            <div class="container">
                <?php
                    $selector = $_GET["selector"];
                    $validator = $_GET["validator"];


                    if (empty($selector) || empty($validator)) {
                        echo "<div class='alert alert-danger'> Não foi possível validar sua solicitação </div>";
                    } else {
                        if (ctype_xdigit($selector) !== false && ctype_xdigit($validator) !== false) {
                            ?>

                                <form action="reset-password.inc.php" method="post">

                                    <input type="hidden" name="selector" value="<?php echo $selector ?>">
                                    <input type="hidden" name="validator" value="<?php echo $validator ?>">
                                    <input type="password" name="pwd" placeholder="Insira sua nova senha;">
                                    <input type="password" name="pwd-repeat" placeholder="Repita sua nova senha;">
                                    <button type="submit" name="reset-password-submit"> Redefinir senha </button>
                                </form>




                            <?php
                        }
                    }
                ?>               

            </div>
        </body>
    </html>