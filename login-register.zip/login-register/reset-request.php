<?php 

if(isset($_POST["reset-request-submit"])) {

    $selector = bin2hex(random_bytes(8)); // binary to hex
    $token = random_bytes(32);

    $url = "http://localhost/login-register/create-new-password.php?selector=" . $selector . "&validator=" . bin2hex($token);

    $expires = date("U") + 1800;

    require "database.php";

    $userEmail = $_POST["email"];

    $sql  = "DELETE FROM pwdReset WHERE pwdResetEmail=?;";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        echo "<div class='alert alert-danger'> Houve um erro </div>";
        exit();
    } else {
        mysqli_stmt_bind_param($stmt, "s", $userEmail);
        mysqli_stmt_execute($stmt);
    }

    $sql = "INSERT INTO pwdReset (pwdResetEmail, pwdResetSelector, pwdResetToken, pwdResetExpires) VALUES (?, ?, ?, ?);";

    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        echo "<div class='alert alert-danger'> Houve um erro </div>";
        exit();
    } else {
        $hashedToken = password_hash($token, PASSWORD_DEFAULT);
        mysqli_stmt_bind_param($stmt, "ssss", $userEmail, $selector, $hashedToken, $expires);
        mysqli_stmt_execute($stmt);
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn); // erro

    $to = $userEmail;

    $subject = 'Redefina sua senha';

    $message = '<p> Recebemos uma solicitação para alterar sua senha. O link para redefinri sua senha está abaixo, se você não solicitou isso pode ignorar este email </p>';
    $message .=  '<p> Link para redefinição de senha:  </br>';
    $message .=  '<a href="' . $url . '">' . $url . '</a> </p>';

    $headers = "From: Sofia <sofia.fernandesfs4@gmail.com>\r\n";
    $headers .= "Reply-To: sofia.fernandesfs4@gmail.com\r\n";
    $headers .= "Content-type: text/html\r\n";

    mail($to, $subject, $message, $headers);

    header("Location : reset-password.php?reset=success");


} else {
    header("Location : login.php");
}



?>