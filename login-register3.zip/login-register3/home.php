<?php
require_once 'database.php';

$sql = "SELECT * FROM startups;";
$all_info = $conn->query($sql);

if ($all_info === false) {
    die("Error executing query: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link rel="stylesheet" href="home.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
</head>
<body>
    <main>
    <?php 
        while($row = mysqli_fetch_assoc($all_info)){
    ?>
        <div class="card">
            <div class="header">
                <h2 class="title"><?php echo $row["nomeStartup"]; ?></h2>
                <h4 class="founders"><?php echo $row["fundador"]; ?></h4>
                <p class="niche"><?php echo $row["setor"]; ?></p>
            </div>
            <div class="info">
                <p class="desc"><?php echo $row["descricao"]; ?></p>
                <p class="website"><?php echo $row["website"]; ?></p>
                <p class="contact"><?php echo $row["contato"]; ?></p>
                <p class="adress"><?php echo $row["endereco"]; ?></p>
                <button class="contact-them">contact</button>
            </div>
        </div>
        <?php 
        }
    ?>
    </main>
</body>
</html>